import React from 'react';
import logo from './logo.svg';
import './App.css';
// import axios from "axios";
import { useEffect, useState } from "react";
// function handleClick() {
//   const xhr = new XMLHttpRequest();
//   xhr.open('GET', 'https://api.example.com/data');
//   xhr.onload = function() {
//     if (xhr.status === 200) {
//       setData(JSON.parse(xhr.responseText));
//     }
//   };
//   xhr.send();
// }


// useEffect(() => {
//   window.scroll(0, 0);
//   fetchSeries();
//   // eslint-disable-next-line
// }, [genreforURL, page]);
function App() {
  const [data, setData] = useState(null);
  const [count, setCount] = useState(2023); 
  function increment() {
    //setCount(prevCount => prevCount+=1);
    if(count<2023){
    setCount(function (prevCount) {
      return (prevCount += 1);
    });
   
    handleClick(count+1);}
  }

  function decrement() {
    setCount(function (prevCount) {
      if (prevCount > 2012) {
        return (prevCount -= 1); 
        
      } else {
        return (prevCount = 2012);
      }
    
    });
     
  }
  function d1(){
    decrement();
    if(count>2012){
    handleClick(count-1);
    }
  }
  function handleClick(y) {
    
    var url='https://api.themoviedb.org/3/discover/movie?api_key=2dca580c2a14b55200e784d157207b4d&sort_by=popularity.desc&primary_release_year='+y+'&page=1&vote_count.gte=100';
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url);
    xhr.onload = function() {
      if (xhr.status === 200) {
        setData(JSON.parse(xhr.responseText));
       

      }
    };
    xhr.send();

     }
    
     function moredata(){
      let x=2023;
       x=x-1;
       
      console.log(x);
      handleClick(x);
     }
//  function componentDidMount () {
  useEffect(() => {
    handleClick(2023);
    console.log('mount it!');
  }, []);
// }
  
  return (
    <div className="App">
      <header className="App-header">
       {/* <img src={logo} className="App-logo" alt="logo" />
        <h1>Hello</h1>
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
  </a>*/}
  <h2>Movieflix</h2><br/>
  <nav > <a className="p1">All</a><a className="p1">Action</a><a className="p1">Comedy</a></nav>
      
      <div>
      <h1>{count}</h1>
      {data ? <div>
      {/* {JSON.stringify(data.results)} */}
      <ul style={{listStyleType:"none"}}>
        {data.results.map((season) => (
          <li key={season.id}>
          <img src={season.poster_path} alt="logo"/><br/>
          <b>Movie:</b>{season.original_title}  <i>  <b>Release Date:</b>{season.release_date}</i></li>
        ))}
      </ul>
      <div style={{padding:"15px"}}>
      <button onClick={increment}>Previous Data</button>
      <button onClick={d1}>More Data</button></div>
      {/* <img src={data[0].poster_path} alt="title" height="100px" width="auto"/> */}
      </div> : <div>Loading...</div>}
    </div>
    {/* </div> */}
    </header></div>
  );
}

export default App;
